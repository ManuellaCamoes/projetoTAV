package sistema;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestandoContatos {

	@Test
	void setNomeVazio() {
		
		Contatos c = new Contatos();
		
		String nomeTeste = "";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = c.setNome(nomeTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void setNomeComCaractereNaoLetra() {
		
		Contatos c = new Contatos();
		
		String nomeTeste = "M4anuella";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = c.setNome(nomeTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}

	@Test
	void setNomeValidoa() {
		
		Contatos c = new Contatos();
		
		String nomeTeste = "Manuella";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = c.setNome(nomeTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void alterarNomeVazio() {
		
		Contatos c = new Contatos();
		
		String nomeTeste = "";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = c.alterarNome(nomeTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void alterarNomeComCaractereNaoLetra() {
		
		Contatos c = new Contatos();
		
		String nomeTeste = "M4anuella";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = c.alterarNome(nomeTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}

	@Test
	void alterarNomeValidoa() {
		
		Contatos c = new Contatos();
		
		String nomeTeste = "Manuella";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = c.alterarNome(nomeTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void setTelefoneComcaractereNaoNumero() {
		
		Contatos c = new Contatos();
		
		String telefoneTeste = "99999M999";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = c.setTelefone(telefoneTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void setTelefoneValido() {
		
		Contatos c = new Contatos();
		
		String telefoneTeste = "21979636145";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = c.setTelefone(telefoneTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void alterarTelefoneComcaractereNaoNumero() {
		
		Contatos c = new Contatos();
		
		String telefoneTeste = "99999M999";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = c.alterarTelefone(telefoneTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void alterarTelefoneValido() {
		
		Contatos c = new Contatos();
		
		String telefoneTeste = "21979636145";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = c.alterarTelefone(telefoneTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void setEmailInvalido() {
		
		Contatos c = new Contatos();
		
		String emailTeste = "manuella";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = c.setEmail(emailTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void setEmailValido() {
		
		Contatos c = new Contatos();
		
		String emailTeste = "manuella@emal.com";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = c.setEmail(emailTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void alterarEmailInvalido() {
		
		Contatos c = new Contatos();
		
		String emailTeste = "manuella";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = c.alterarEmail(emailTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void alterarEmailValido() {
		
		Contatos c = new Contatos();
		
		String emailTeste = "manuella@emal.com";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = c.alterarEmail(emailTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void apagarContato() {
		
		Contatos a = new Contatos();
		
		boolean resultadoEsperado = true;
		
		a.apagarContato();
		
		boolean resultado = a.getApagar();
		
		assertEquals(resultado, resultadoEsperado);
		
	}
}
