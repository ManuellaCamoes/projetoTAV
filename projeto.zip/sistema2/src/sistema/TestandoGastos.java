package sistema;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestandoGastos {

	@Test
	void setGastoEmBranco() {
		
		Gastos g = new Gastos();
		
		String gastoTeste = "";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = g.setGasto(gastoTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setGastoValido() {
		
		Gastos g = new Gastos();
		
		String gastoTeste = "Presente de Natal";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = g.setGasto(gastoTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarGastoEmBranco() {
		
		Gastos g = new Gastos();
		
		String gastoTeste = "";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = g.alterarGasto(gastoTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarGastoValido() {
		
		Gastos g = new Gastos();
		
		String gastoTeste = "Presente de Natal";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = g.alterarGasto(gastoTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setValorInvalido() {
		
		Gastos v = new Gastos();
		
		double valorTeste = -5;
		
		boolean resultadoEsperado = false;
		
		boolean resultado = v.setValor(valorTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setValorInvalido2() {
		
		Gastos v = new Gastos();
		
		double valorTeste = 0;
		
		boolean resultadoEsperado = false;
		
		boolean resultado = v.setValor(valorTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setValorValido() {
		
		Gastos v = new Gastos();
		
		double valorTeste = 25.00;
		
		boolean resultadoEsperado = true;
		
		boolean resultado = v.setValor(valorTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}

	@Test
	void alterarValorInvalido() {
		
		Gastos v = new Gastos();
		
		double valorTeste = -5;
		
		boolean resultadoEsperado = false;
		
		boolean resultado = v.alterarValor(valorTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarValorInvalido2() {
		
		Gastos v = new Gastos();
		
		double valorTeste = 0;
		
		boolean resultadoEsperado = false;
		
		boolean resultado = v.alterarValor(valorTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarValorValido() {
		
		Gastos v = new Gastos();
		
		double valorTeste = 25.00;
		
		boolean resultadoEsperado = true;
		
		boolean resultado = v.alterarValor(valorTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void apagarGasto() {
		
		Gastos a = new Gastos();
		
		boolean resultadoEsperado = true;
		
		a.apagarGasto();
		
		boolean resultado = a.getApagar();
		
		assertEquals(resultado, resultadoEsperado);
		
	}
}
