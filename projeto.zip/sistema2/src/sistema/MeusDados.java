package sistema;

public class MeusDados {

	String cpf;
	String rg;
	String placaCarro; //abc1234 ou abc1d23 4 letras e 3 numeros ou 3 letras e 4 numeros
	int quantLetra, quantNumero, contador;
	
	public String getCpf() {
		return cpf;
	}
	public String getRg() {
		return rg;
	}

	public String getPlacaCarro() {
		return placaCarro;
	}

	public boolean setCpf(String cpf) {
		
		if(cpf.length() != 11) {
			return false; //cpf com tamanho diferente de 11
		}
		
		   for (int i=0; i<cpf.length(); i++){
	            if(Character.isDigit(cpf.charAt(i)) == false){
	                contador ++;
	            }
	        }
		
		   if(contador != 0) {
			   return false; //cpf com caractere nao numerico
		   }
		   
		this.cpf = cpf;
		return true;
			
	}
	
	public boolean alterarCpf(String cpf) {
		
		if(cpf.length() != 11) {
			return false; //cpf com tamanho diferente de 14
		}
		
		   for (int i=0; i<cpf.length(); i++){
	            if(Character.isDigit(cpf.charAt(i)) == false){
	                contador ++;
	            }
	        }
		
		   if(contador != 0) {
			   return false; //cpf com caractere nao numerico
		   }
		   
		this.cpf = cpf;
		return true;
			
	}
	
	public boolean setRg(String rg) {
		
		if(rg.length() != 9) {
			return false;
		}
		
		   for (int i=0; i<rg.length(); i++){
	            if(Character.isDigit(rg.charAt(i)) == false){
	                contador ++;
	            }
	        }
		  
		   if(contador!=0) {
			   return false;
		   }
		
		this.rg = rg;
		return true;
		
	}
	
	public boolean alterarRg(String rg) {
		
		if(rg.length() != 9) {
			return false;
		}
		
		   for (int i=0; i<rg.length(); i++){
	            if(Character.isDigit(rg.charAt(i)) == false){
	                contador ++;
	            }
	        }
		  
		   if(contador!=0) {
			   return false;
		   }
		
		this.rg = rg;
		return true;
		
	}
	
	public boolean setPlacaCarro(String placaCarro) {
		
		if(placaCarro.length() != 7) {
			return false;
		}
		
		   for (int i=0; i<placaCarro.length(); i++){
	            if(Character.isDigit(placaCarro.charAt(i))){
	                quantNumero ++;
	            }
	        }
		   
		 if(quantNumero == 0) { //se n�o tiver nenhum n�mero na placa
			 return false;
		 }
		 
		   for (int i=0; i<placaCarro.length(); i++){
	            if(Character.isAlphabetic(placaCarro.charAt(i))){
	                quantLetra ++;
	            }
	        }
		   
		  if(quantLetra == 0) { //se n�o tiver nenhuma letra
			  return false;
		  }
		   
		 if((quantNumero != 4 && quantNumero != 3)) {
			 return false; // se a quantidade de numero for diferente de 4 ou 3
		 }
		 
		 if((quantLetra == 3) && (Character.isAlphabetic(placaCarro.charAt(0)) == false) || (Character.isAlphabetic(placaCarro.charAt(1)) == false) || (Character.isAlphabetic(placaCarro.charAt(2)) == false)) {
			 return false;
		 }//se tiver 3 letras, verificando se est�o nas posi��es corretas
		
		 if((quantNumero == 3) && (Character.isDigit(placaCarro.charAt(3)) == false) || (Character.isDigit(placaCarro.charAt(5)) == false) || (Character.isDigit(placaCarro.charAt(6)) == false)) {
			 return false;
		 }//se tiver 3 numeros, verificando se est�o nas posi��es corretas
		 
		this.placaCarro = placaCarro;
		return true;
		
	}
	
		public boolean alterarPlacaCarro(String placaCarro) {
		
		if(placaCarro.length() != 7) {
			return false;
		}
		
		   for (int i=0; i<placaCarro.length(); i++){
	            if(Character.isDigit(placaCarro.charAt(i))){
	                quantNumero ++;
	            }
	        }
		   
		 if(quantNumero == 0) { //se n�o tiver nenhum n�mero na placa
			 return false;
		 }
		 
		   for (int i=0; i<placaCarro.length(); i++){
	            if(Character.isAlphabetic(placaCarro.charAt(i))){
	                quantLetra ++;
	            }
	        }
		   
		  if(quantLetra == 0) { //se n�o tiver nenhuma letra
			  return false;
		  }
		   
		 if((quantNumero != 4 && quantNumero != 3)) {
			 return false; // se a quantidade de numero for diferente de 4 ou 3
		 }
		 
		 if((quantLetra == 3) && (Character.isAlphabetic(placaCarro.charAt(0)) == false) || (Character.isAlphabetic(placaCarro.charAt(1)) == false) || (Character.isAlphabetic(placaCarro.charAt(2)) == false)) {
			 return false;
		 }//se tiver 3 letras, verificando se est�o nas posi��es corretas
		
		 if((quantNumero == 3) && (Character.isDigit(placaCarro.charAt(3)) == false) || (Character.isDigit(placaCarro.charAt(5)) == false) || (Character.isDigit(placaCarro.charAt(6)) == false)) {
			 return false;
		 }//se tiver 3 numeros, verificando se est�o nas posi��es corretas
		 
		this.placaCarro = placaCarro;
		return true;
		
	}
}
