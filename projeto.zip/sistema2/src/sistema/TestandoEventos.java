package sistema;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestandoEventos {

	@Test
	void setEventoEmBranco() {
		
		Eventos e = new Eventos();
		
		String eventoTeste = "";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = e.setEvento(eventoTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setEventoValido() {
		
		Eventos e = new Eventos();
		
		String eventoTeste = "Anivers�rio da Karen";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = e.setEvento(eventoTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarEventoEmBranco() {
		
		Eventos e = new Eventos();
		
		String eventoTeste = "";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = e.alterarEvento(eventoTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarEventoValido() {
		
		Eventos e = new Eventos();
		
		String eventoTeste = "Anivers�rio da Karen";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = e.alterarEvento(eventoTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}

	@Test
	void testeSetDataEmBranco() {
		
		Eventos e = new Eventos();
		
		String dataTeste = "";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = e.setEvento(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void testeSetDataInvalida() {
		
		Eventos e = new Eventos();
		
		String dataTeste = "09090909";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = e.setData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void testeSetDataExpirada() {
		
		Eventos e = new Eventos();
		
		String dataTeste = "01/06/2000";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = e.setData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}

	@Test
	void testeSetDataHoje() {
		
		Eventos e = new Eventos();
		
		String dataTeste = "26/11/2020";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = e.setData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void testeSetDataFuturo() {
		
		Eventos e = new Eventos();
		
		String dataTeste = "01/06/2021";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = e.setData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void testealterarDataEmBranco() {
		
		Eventos e = new Eventos();
		
		String dataTeste = "";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = e.alterarData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void testealterarDataInvalida() {
		
		Eventos e = new Eventos();
		
		String dataTeste = "09090909";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = e.alterarData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void testealterarDataExpirada() {
		
		Eventos e = new Eventos();
		
		String dataTeste = "01/06/2000";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = e.alterarData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}

	@Test
	void testealterarDataHoje() {
		
		Eventos e = new Eventos();
		
		String dataTeste = "25/11/2020";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = e.alterarData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void testeAlterarDataFuturo() {
		
		Eventos e = new Eventos();
		
		String dataTeste = "01/06/2021";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = e.alterarData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	
	@Test
	void testeHorarioVazio() {
		
		Eventos h = new Eventos();
		
		String horarioTeste = "";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = h.setHorario(horarioTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	

	@Test
	void testeHorarioFormatoInvalido() {
		
		Eventos h = new Eventos();
		
		String horarioTeste = "2300";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = h.setHorario(horarioTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
		
	@Test
	void testeHorarioInvalido1() {
		
		Eventos h = new Eventos();
		
		String horarioTeste = "3:00";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = h.setHorario(horarioTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	
	@Test
	void testeHorarioInvalido2() {
		
		Eventos h = new Eventos();
		
		String horarioTeste = "m3:00";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = h.setHorario(horarioTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void testeHorarioInvalido3() {
		
		Eventos h = new Eventos();
		
		String horarioTeste = "15:m0";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = h.setHorario(horarioTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void testeHorarioValido() {
		
		Eventos h = new Eventos();
		
		String horarioTeste = "15:00";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = h.setHorario(horarioTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	

	@Test
	void testeAlterarHorarioVazio() {
		
		Eventos h = new Eventos();
		
		String horarioTeste = "";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = h.alterarHorario(horarioTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	

	@Test
	void testeAlterarHorarioFormatoInvalido() {
		
		Eventos h = new Eventos();
		
		String horarioTeste = "2300";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = h.alterarHorario(horarioTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
		
	@Test
	void testeAlterarHorarioInvalido1() {
		
		Eventos h = new Eventos();
		
		String horarioTeste = "3:00";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = h.alterarHorario(horarioTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	
	@Test
	void testeAlterarHorarioInvalido2() {
		
		Eventos h = new Eventos();
		
		String horarioTeste = "m3:00";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = h.alterarHorario(horarioTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void testeAlterarHorarioInvalido3() {
		
		Eventos h = new Eventos();
		
		String horarioTeste = "15:m0";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = h.alterarHorario(horarioTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void testeAlterarHorarioValido() {
		
		Eventos h = new Eventos();
		
		String horarioTeste = "15:00";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = h.alterarHorario(horarioTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	
	@Test
	void apagarEvento() {
		
		Eventos a = new Eventos();
		
		boolean resultadoEsperado = true;
		
		a.apagarEvento();
		
		boolean resultado = a.getApagar();
		
		assertEquals(resultado, resultadoEsperado);
		
	}
}



