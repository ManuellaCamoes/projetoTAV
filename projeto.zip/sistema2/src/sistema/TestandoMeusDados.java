package sistema;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestandoMeusDados {

	@Test
	void setCpfTamanhoPequeno() {
		
		MeusDados d = new MeusDados();
		
		String cpfTeste = "2";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = d.setCpf(cpfTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}

	
	@Test
	void setCpfTamanhoGrande() {
		
		MeusDados d = new MeusDados();
		
		String cpfTeste = "2222222222222222222222222222";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = d.setCpf(cpfTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setCpfErrado() {
		
		MeusDados d = new MeusDados();
		
		String cpfTeste = "123123123mm";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = d.setCpf(cpfTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setCpfValido() {
		
		MeusDados d = new MeusDados();
		
		String cpfTeste = "14687955588";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = d.setCpf(cpfTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarCpfTamanhoPequeno() {
		
		MeusDados d = new MeusDados();
		
		String cpfTeste = "2";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = d.alterarCpf(cpfTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}

	
	@Test
	void alterarCpfTamanhoGrande() {
		
		MeusDados d = new MeusDados();
		
		String cpfTeste = "2222222222222222222222222222";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = d.alterarCpf(cpfTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarCpfErrado() {
		
		MeusDados d = new MeusDados();
		
		String cpfTeste = "123123123mm";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = d.alterarCpf(cpfTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarCpfValido() {
		
		MeusDados d = new MeusDados();
		
		String cpfTeste = "14687955500";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = d.alterarCpf(cpfTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	@Test
	void setRgPequeno() {
		
		MeusDados r = new MeusDados();
		
		String rgTeste = "123";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = r.setRg(rgTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setRgGrande() {
		
		MeusDados r = new MeusDados();
		
		String rgTeste = "123123123123123";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = r.setRg(rgTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setRgErrado() {
		
		MeusDados r = new MeusDados();
		
		String rgTeste = "123123123mm";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = r.setRg(rgTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setRgValido() {
		
		MeusDados r = new MeusDados();
		
		String rgTeste = "285559371";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = r.setRg(rgTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarRgPequeno() {
		
		MeusDados r = new MeusDados();
		
		String rgTeste = "123";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = r.alterarRg(rgTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarRgGrande() {
		
		MeusDados r = new MeusDados();
		
		String rgTeste = "123123123123123";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = r.alterarRg(rgTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarRgErrado() {
		
		MeusDados r = new MeusDados();
		
		String rgTeste = "123123123mm";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = r.alterarRg(rgTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarRgValido() {
		
		MeusDados r = new MeusDados();
		
		String rgTeste = "285559371";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = r.alterarRg(rgTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaPequena() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "m123";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaSemNumero() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "abcdefg";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaSemLetra() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "1234567";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaErrada1() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "ab12345"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaErrada2() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "abcde12"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaErrada3() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "a1bc234"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaErrada4() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "1abc234"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaErrada5() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "ab1c234"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaErrada6() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "1234abc"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaErrada7() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "a1234bc"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaErrada8() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "abc12d3"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaErrada9() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "abcd123"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaErrada10() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "abc12d3"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaCerta1() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "abc1234"; 
		
		boolean resultadoEsperado = true;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void setPlacaCerta2() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "abc1d23"; 
		
		boolean resultadoEsperado = true;
		
		boolean resultado = p.setPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaPequena() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "m123";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaSemNumero() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "abcdefg";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaSemLetra() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "1234567";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaErrada1() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "ab12345"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaErrada2() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "abcde12"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaErrada3() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "a1bc234"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaErrada4() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "1abc234"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaErrada5() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "ab1c234"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaErrada6() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "1234abc"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaErrada7() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "a1234bc"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaErrada8() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "abc12d3"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaErrada9() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "abcd123"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaErrada10() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "abc12d3"; 
		
		boolean resultadoEsperado = false;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaCerta1() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "abc1234"; 
		
		boolean resultadoEsperado = true;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
	
	@Test
	void alterarPlacaCerta2() {
		
		MeusDados p = new MeusDados();
		
		String placaTeste = "abc1d23"; 
		
		boolean resultadoEsperado = true;
		
		boolean resultado = p.alterarPlacaCarro(placaTeste);
		
		assertEquals(resultado, resultadoEsperado);
	}
}




