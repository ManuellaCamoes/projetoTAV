package sistema;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

public class Eventos {

	String evento;
	String data;
	String horario; //00:00
	private LocalDate hoje = LocalDate.now();
	boolean apagar = false;
	
	public String getEvento() {
		return evento;
	}

	public String getData() {
		return data;
	}
	
	public String getHorario() {
		return horario;
	}
	
	public boolean getApagar() {
		return apagar;
	}
	
	public boolean setEvento(String evento) {
		
		if(evento == "") {//evento vazio
			return false;
		}
		
	
		this.evento = evento;
		return true;
	}
	
	public boolean alterarEvento(String evento) {
		
		if(evento == "") {//evento vazio
			return false;
		}
		
	
		this.evento = evento;
		return true;
	}
	
	public boolean setData(String data) {
		
		int contagem = 0;
		
		if(data == "") {//data vazia
			return false;
			
		}
		
	
        for (int i=0; i<data.length(); i++){
            if(data.charAt(i) == '/'){
                contagem ++;
            }
        }
    
        if(contagem != 2) {//data sem nenhuma barra
        	return false;
        }
		
        if(isDateValid(data) ==  false) {
        	return true; //data que n�o existe
        }
        
       
		
		if ((configuraData(data)).isBefore(hoje)) {
			return false;//data expirada
		}
		
        	
		this.data = data;
		return true;

	}
	
	public boolean alterarData(String data) {
		
		int contagem = 0;
		
		if(data == "") {
			return false;
			
		}
		
	
        for (int i=0; i<data.length(); i++){
            if(data.charAt(i) == '/'){
                contagem ++;
            }
        }
    
        if(contagem != 2) {
        	return false;
        }
		
        if(isDateValid(data) ==  false) {
        	return true;
        }
        
       
		
		if ((configuraData(data)).isBefore(hoje)) {
			return false;
		}
		
        	
		this.data = data;
		return true;

	}
	
	
	public boolean setHorario(String horario) {
		
		int quant = 0;
		
            
        if(horario == "") {
        	return false;//horario vazio
        }
        
        for (int i = 0; i < horario.length(); i++){
            if(horario.charAt(i) == ':'){
                quant ++;//horario sem dois pontos
            }
        }
        
        if(quant != 1) {
        	return false;
        	
        }
        
        if(horario.length() != 5) {
        	return false;  //horario com tamanho diferente de 5
        }
		
        if(Character.isDigit(horario.charAt(0)) == false || Character.isDigit(horario.charAt(1)) == false || Character.isDigit(horario.charAt(3)) == false || Character.isDigit(horario.charAt(4)) == false) {
        	return false; //horario como caractere nao numerico (alem dos dois pontos)
        }
     
        
		
		this.horario = horario;
		return true;
	}
	
	public boolean alterarHorario(String horario) {
		
		int quant = 0;
		
            
        if(horario == "") {
        	return false;
        }
        
        for (int i = 0; i < horario.length(); i++){
            if(horario.charAt(i) == ':'){
                quant ++;
            }
        }
        
        if(quant != 1) {
        	return false;
        	
        }
        
        if(horario.length() != 5) {
        	return false;
        }
		
        if(Character.isDigit(horario.charAt(0)) == false || Character.isDigit(horario.charAt(1)) == false || Character.isDigit(horario.charAt(3)) == false || Character.isDigit(horario.charAt(4)) == false) {
        	return false;
        }
     
        
		
		this.horario = horario;
		return true;
	}
	
	
	public void apagarEvento() {
		this.apagar = true;
				
	}
	
	
	public static boolean isDateValid(String strDate) {
	    String dateFormat = "dd/MM/uuuu";

	    DateTimeFormatter dateTimeFormatter = DateTimeFormatter
	    .ofPattern(dateFormat)
	    .withResolverStyle(ResolverStyle.STRICT);
	    try {
	        LocalDate date = LocalDate.parse(strDate, dateTimeFormatter);
	        return true;
	    } catch (DateTimeParseException e) {
	       return false;
	    } 
	}
	
	public LocalDate configuraData(String date) {
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy"); 
		LocalDate data2 = LocalDate.parse(date, formato);
		return data2;
	
}
	
	
	
	
}
