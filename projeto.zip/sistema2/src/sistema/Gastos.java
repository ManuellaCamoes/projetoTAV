package sistema;

public class Gastos {
	
	String gasto;
	double valor;
	boolean apagar = false;
	
	public String getGasto() {
		return gasto;
	}

	public double getValor() {
		return valor;
	}
	
	public boolean getApagar() {
		return apagar;
	}

	
	public boolean setGasto(String gasto) {
		
		if(gasto == "") {
			return false;
		}
		
		this.gasto = gasto;
		return true;
		
	}
	
	public boolean alterarGasto(String gasto) {
		
		if(gasto == "") {
			return false;
		}
		
		this.gasto = gasto;
		return true;
		
	}
	
	public boolean setValor (double valor) {
		
		if(valor <= 0.00) {
			return false;
		}
		

		this.valor = valor;
		return true;
		
	}
	
	public boolean alterarValor (double valor) {
		
		if(valor <= 0.00) {
			return false;
		}
		

		this.valor = valor;
		return true;
		
	}
	
	public void apagarGasto() {
		this.apagar = true;
				
	}
}
