package sistema;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Contatos {
	
	String nome;
	String telefone;
	String email;
	int contador;
	boolean apagar = false;
	
	
	public String getNome() {
		return nome;
	}

	public String getTelefone() {
		return telefone;
	}

	public String getEmail() {
		return email;
	}
	
	public boolean getApagar() {
		return apagar;
	}

		
	public boolean setNome(String nome) {
		
		if(nome == "") {
			return false;
		}
		
        for (int i=0; i<nome.length(); i++){
            if(Character.isAlphabetic(nome.charAt(i)) == false){
                contador ++;
            }
        }
        // verificando se tem algum caractere que nao seja letra
        if(contador != 0) {
        	return false;
        }
		
		this.nome = nome;
		return true;
	}
	
	public boolean alterarNome(String nome) {
		
		if(nome == "") {
			return false;
		}
		
        for (int i=0; i<nome.length(); i++){
            if(Character.isAlphabetic(nome.charAt(i)) == false){
                contador ++;
            }
        }
        
        if(contador != 0) {
        	return false;
        }
		
		this.nome = nome;
		return true;
	}
	
	
	public boolean setTelefone(String telefone) {
		
        for (int i=0; i<telefone.length(); i++){
            if(Character.isDigit(telefone.charAt(i)) == false){
                contador ++;
            }
        }
		
        if(contador != 0) {
        	return false;
        }
		
		this.telefone = telefone;
		return true;
	}
	
	
	public boolean alterarTelefone(String telefone) {
		
        for (int i=0; i<telefone.length(); i++){
            if(Character.isDigit(telefone.charAt(i)) == false){
                contador ++;
            }
        }
		
        if(contador != 0) {
        	return false;
        }
		
		this.telefone = telefone;
		return true;
	}
	
	public boolean setEmail(String email) {
		
		if(validacaoEmail(email) == false) {
			return false;
		}
		
		this.email = email;
		return true;
	}
	
	public boolean alterarEmail(String email) {
		
		if(validacaoEmail(email) == false) {
			return false;
		}
		
		this.email = email;
		return true;
	}
	
	public void apagarContato() {
		this.apagar = true;
				
	}
	
	public static boolean validacaoEmail(String email) {
	    boolean isEmailIdValid = false;
	    if (email != null && email.length() > 0) {
	        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
	        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
	        Matcher matcher = pattern.matcher(email);
	        if (matcher.matches()) {
	            isEmailIdValid = true;
	        }
	    }// func��o para vericiar se � um email v�lido
	    return isEmailIdValid;
	}
	
	

}
