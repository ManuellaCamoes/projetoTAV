package sistema;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

public class Tarefas {

	private String tarefa;
	private String descricao;
	private String data; //dd/mm/aaaa
	private LocalDate hoje = LocalDate.now(); // data atual
	boolean apagar = false;
	
	
	public String getTarefa() {
		return tarefa;
	}

	public String getDescricao() {
		return descricao;
	}
	
	public String getData() {
		return data;
	}
	
	public boolean getApagar() {
		return apagar;
	}
	
	public boolean setTarefa(String tarefa) {
		
		if(tarefa.length() > 50) {
			return false;
		}
	
		if(tarefa == "") {
			return false;
		}
	
		this.tarefa = tarefa;
		return true;
	}
	
	
	public boolean alterarTarefa(String tarefa) {
		
		if(tarefa.length() > 50) {
			return false;
		}
	
		if(tarefa == "") {
			return false;
		}
	
		this.tarefa = tarefa;
		return true;
	}
	
	public void apagarTarefa() {
		
		this.apagar = true;
		
	}
	
	
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	
	}
	
	
	public void alterarDescricao(String descricao) {
		this.descricao = descricao;
	
	}
	
	public boolean setData(String data) {
		
		int contagem = 0;
		
		if(data == "") {
			return false;
			
		}
		
	
        for (int i=0; i<data.length(); i++){
            if(data.charAt(i) == '/'){
                contagem ++;
            }
        }
    
        if(contagem != 2) {
        	return false;
        }
		
        if(isDateValid(data) ==  false) {
        	return false;
        }
        
       
		
		if ((configuraData(data)).isBefore(hoje)) {
			return false;
		}
		
        	
		this.data = data;
		return true;
		
				
	}
	
		public boolean alterarData(String data) {
		
		int contagem = 0;
		
		if(data == "") {
			return false;
			
		}
		
	
        for (int i=0; i<data.length(); i++){
            if(data.charAt(i) == '/'){
                contagem ++;
            }
        }
    
        if(contagem != 2) {
        	return false;
        }
		
        if(isDateValid(data) ==  false) {
        	return false;
        }
        
       
		
		if ((configuraData(data)).isBefore(hoje)) {
			return false;
		}
		
        	
		this.data = data;
		return true;
		
				
	}
	

	public static boolean isDateValid(String strDate) {
	    String dateFormat = "dd/MM/uuuu";

	    DateTimeFormatter dateTimeFormatter = DateTimeFormatter
	    .ofPattern(dateFormat)
	    .withResolverStyle(ResolverStyle.STRICT);
	    try {
	        LocalDate date = LocalDate.parse(strDate, dateTimeFormatter);
	        return true;
	    } catch (DateTimeParseException e) {
	       return false;
	    } 
	} // fun��o para validar se a data inserida � v�lida
	
	
	public LocalDate configuraData(String date) {
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy"); 
		LocalDate data2 = LocalDate.parse(date, formato);
		return data2;
	} // fun��o para configurar a data como LocalDate para poder comparar com a data atual

}
