package sistema;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import sistema.Tarefas;

class TestandoTarefa {

	@Test
	void testeSetTarefaEmBranco() {
		
		Tarefas t = new Tarefas();
		
		String tarefaTeste = "";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = t.setTarefa(tarefaTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void testeSetTarefaMuitoGrande() {
		
		Tarefas t = new Tarefas();
		
		String tarefaTeste = "teste teste teste teste teste teste teste teste teste teste teste teste teste teste teste teste teste teste teste teste";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = t.setTarefa(tarefaTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void testeSetTarefaValida() {
		
		Tarefas t = new Tarefas();
		
		String tarefaTeste = "Ir ao mercado";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = t.setTarefa(tarefaTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void testeAlterarTarefaEmBranco() {
		
		Tarefas t = new Tarefas();
		
		String tarefaTeste = "";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = t.alterarTarefa(tarefaTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void testeAlterarTarefaMuitoGrande() {
		
		Tarefas t = new Tarefas();
		
		String tarefaTeste = "teste teste teste teste teste teste teste teste teste teste teste teste teste teste teste teste teste teste teste teste";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = t.alterarTarefa(tarefaTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void testeAlterarTarefaValida() {
		
		Tarefas t = new Tarefas();
		
		String tarefaTeste = "Ir ao m�dico";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = t.alterarTarefa(tarefaTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}	
	
	@Test
	void testeSetDataVazia() {
		
		Tarefas d = new Tarefas();
		
		String dataTeste = "";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = d.setData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
		
	@Test
	void testeSetDataFormatoInvalido() {
		
		Tarefas d = new Tarefas();
		
		String dataTeste = "11102020";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = d.setData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void testeSetDataInvalida() { //data n�o existe
		
		Tarefas d = new Tarefas();
		
		String dataTeste = "30/02/2021";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = d.setData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void testeSetDataExpirada() {
		
		Tarefas d = new Tarefas();
		
		String dataTeste = "15/11/2020";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = d.setData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void testeSetDataHoje() {//testando se pode colocar a data atual
		
		Tarefas d = new Tarefas();
		
		String dataTeste = "26/11/2020";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = d.setData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void testeSetDataFuturo() {//testando se pode colocar a data atual
		
		Tarefas d = new Tarefas();
		
		String dataTeste = "30/11/2020";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = d.setData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	
	@Test
	void testeAlterarDataVazia() {
		
		Tarefas d = new Tarefas();
		
		String dataTeste = "";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = d.alterarData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}

	@Test
	void testeAlterarDataFormatoInvalido() {
		
		Tarefas d = new Tarefas();
		
		String dataTeste = "11102020";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = d.alterarData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void testeAlterarDataInvalida() { //data n�o existe
		
		Tarefas d = new Tarefas();
		
		String dataTeste = "30/02/2021";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = d.alterarData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void testeAlterarDataExpirada() {
		
		Tarefas d = new Tarefas();
		
		String dataTeste = "15/11/2020";
		
		boolean resultadoEsperado = false;
		
		boolean resultado = d.alterarData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	
	@Test
	void testeAlterarDataHoje() {//testando se pode colocar a data atual
		
		Tarefas d = new Tarefas();
		
		String dataTeste = "25/11/2020";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = d.alterarData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	
	@Test
	void testeAlterarDataFuturo() {//testando se pode colocar a data atual
		
		Tarefas d = new Tarefas();
		
		String dataTeste = "30/11/2020";
		
		boolean resultadoEsperado = true;
		
		boolean resultado = d.alterarData(dataTeste);
		
		assertEquals(resultado, resultadoEsperado);
		
	}
	@Test
	void testeSetDescricao() {//testando inser��o de uma descri��o
		
		Tarefas d = new Tarefas();
		
		String descricaoEsperada = "teste";
		
		d.setDescricao(descricaoEsperada);
		
		String resultadoEsperado = d.getDescricao();
		
		assertEquals(resultadoEsperado, descricaoEsperada);
		
	}
	
	@Test
	void testeAlterarDescricao() {//testando inser��o de uma descri��o
		
		Tarefas d = new Tarefas();
		
		String descricaoTeste = "teste";
		
		d.alterarDescricao(descricaoTeste);
		
		String resultadoEsperado = d.getDescricao();
		
		assertEquals(resultadoEsperado, descricaoTeste);
		
	}
	
	@Test
	void apagarTarefa() {
		
		Tarefas a = new Tarefas();
		
		boolean resultadoEsperado = true;
		
		a.apagarTarefa();
		
		boolean resultado = a.getApagar();
		
		assertEquals(resultado, resultadoEsperado);
		
	}
}



